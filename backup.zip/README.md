
  # Interactive Kindergarten ELA Slides (Copy)

  This is a code bundle for Interactive Kindergarten ELA Slides (Copy). The original project is available at https://www.figma.com/design/S5fnoGY87jDB8E4uHDW8lx/Interactive-Kindergarten-ELA-Slides--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  