import { SlideLayout } from '../SlideLayout';

export function Slide08BlendingBoard() {
  return (
    <SlideLayout 
      type="interactive" 
      title="Blending Board" 
      timer={8}
    >
      <div className="flex items-center justify-center h-full max-h-[65vh]">
        <iframe
          src="https://research.dwi.ufl.edu/op.n/file/bca9ju45kvvrvoan/?embed"
          className="w-full h-full rounded-2xl shadow-lg"
          style={{ border: '4px solid var(--ocean-blue)' }}
          title="UFLI Blending Board"
        />
      </div>
    </SlideLayout>
  );
}