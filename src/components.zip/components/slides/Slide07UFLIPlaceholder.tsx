import { SlideLayout } from '../SlideLayout';
import { FileText, ExternalLink } from 'lucide-react';

export function Slide07UFLIPlaceholder() {
  return (
    <SlideLayout type="placeholder" title="UFLI Lesson Time" timer={15}>
      <div className="flex flex-col items-center gap-6 h-full justify-center">
        <div className="text-center space-y-3">
          <p className="text-4xl font-bold" style={{ color: 'var(--deep-navy)' }}>
            Follow Your UFLI Curriculum Guide
          </p>
          <div className="text-xl space-x-6" style={{ color: 'var(--ocean-blue)' }}>
            <span>📖 Vowel sounds review</span>
            <span>✏️ CVC blending</span>
            <span>🎯 Short vs. Long vowels</span>
          </div>
        </div>
        
        <a
          href="https://leonschools-my.sharepoint.com/:p:/g/personal/troopj_leonschools_net/IQDJrxfgxKcYQ5fr7XUA9AJVAVEujzWLqeHIzGUeB_cKRVs?e=HSA5Ld&action=present"
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center gap-6 p-12 rounded-3xl transition-all hover:scale-105 cursor-pointer shadow-2xl border-4 max-w-4xl w-full"
          style={{ 
            backgroundColor: 'var(--seafoam)', 
            borderColor: 'var(--ocean-blue)'
          }}
        >
          <div className="relative">
            <FileText className="w-40 h-40" style={{ color: 'var(--ocean-blue)' }} />
            <ExternalLink className="w-12 h-12 absolute -top-2 -right-2" style={{ color: 'var(--coral)' }} />
          </div>
          
          <div className="text-center space-y-4">
            <p className="text-5xl font-bold" style={{ color: 'var(--deep-navy)' }}>
              Click to Open UFLI Lesson
            </p>
            <p className="text-2xl" style={{ color: 'var(--ocean-blue)' }}>
              Opens in Slideshow Mode (New Tab)
            </p>
          </div>
        </a>
        
        <div className="text-center text-lg" style={{ color: 'var(--ocean-blue)' }}>
          <p>💡 Tip: Keep this tab open to return to the lesson deck</p>
        </div>
      </div>
    </SlideLayout>
  );
}